// Package applications provides a client for the Veracode Applications API.
// It enables retrieving application profiles, policies, sandboxes, and other
// application-related information from the Veracode platform.
package applications

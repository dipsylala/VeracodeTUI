// Package config provides configuration management for the Veracode TUI application.
// It handles loading API credentials from environment variables or YAML configuration files.
package config
